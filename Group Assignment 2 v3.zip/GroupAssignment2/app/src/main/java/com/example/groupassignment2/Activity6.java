package com.example.groupassignment2;

import android.net.Uri;
import android.os.Bundle;
import android.widget.ListView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;
import java.util.List;

public class Activity6 extends AppCompatActivity {

    String reader = "No reader available";
    String result = "No result available";
    String filename;
    Uri uri = Uri.EMPTY;
    List<ItemResult> itemResults = new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_6);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Activity6ListViewAdapter listViewAdapter = new Activity6ListViewAdapter(Activity6.this, R.layout.activity_6_list_item, itemResults);
        ListView listView = findViewById(R.id.listView);
        listView.setAdapter(listViewAdapter);
    }
}