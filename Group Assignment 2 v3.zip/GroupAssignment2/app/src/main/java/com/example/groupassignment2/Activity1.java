package com.example.groupassignment2;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import androidx.appcompat.app.AppCompatActivity;


public class Activity1 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_1);

        ImageView imageViewBarcode = findViewById(R.id.imageViewBarcodeReader);
        ImageView imageViewContent = findViewById(R.id.imageViewContentReader);
        ImageView imageViewText    = findViewById(R.id.imageViewTextReader);
        Button    btnList          = findViewById(R.id.btnListOfAnalysedImages);

        imageViewBarcode.setOnClickListener(v -> openActivity2("barcode"));
        imageViewContent.setOnClickListener(v -> openActivity2("content"));
        imageViewText.setOnClickListener(v    -> openActivity2("text"));

        btnList.setOnClickListener(v -> {
            Intent intent = new Intent(this, Activity6.class);
            startActivity(intent);
        });
    }

    private void openActivity2(String reader) {
        Intent intent = new Intent(this, Activity2.class);
        intent.putExtra("reader", reader);
        startActivity(intent);
    }
}