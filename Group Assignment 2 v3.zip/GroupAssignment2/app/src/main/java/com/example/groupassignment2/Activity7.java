package com.example.groupassignment2;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class Activity7 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_7);

        Button btnEdit = findViewById(R.id.btnEdit);
        Button btnDelete = findViewById(R.id.btnDelete);
        Button btnCancel = findViewById(R.id.btnCancel);

        btnEdit.setOnClickListener(v -> {
            Intent intent = new Intent(this, Activity5.class);
            startActivity(intent);
        });

        btnDelete.setOnClickListener(v -> {
            // Firebase delete logic goes here later
            Intent intent = new Intent(this, Activity6.class);
            startActivity(intent);
        });

        btnCancel.setOnClickListener(v -> {
            Intent intent = new Intent(this, Activity6.class);
            startActivity(intent);
        });
    }
}