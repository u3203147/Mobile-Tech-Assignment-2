package com.example.groupassignment2;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;


import androidx.appcompat.app.AppCompatActivity;


public class Activity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_2);

        // Get the reader value sent from Activity1
        Bundle extras = getIntent().getExtras();
        String reader = (extras != null) ? extras.getString("reader") : "barcode";

        // Show the matching drawable image based on which reader was tapped
        ImageView imageViewSelected = findViewById(R.id.imageViewSelected);
        if ("barcode".equals(reader)) {
            imageViewSelected.setImageResource(R.drawable.barcode);
        } else if ("content".equals(reader)) {
            imageViewSelected.setImageResource(R.drawable.content);
        } else {
            imageViewSelected.setImageResource(R.drawable.text);
        }
        Button btnEditResult = findViewById(R.id.btnEditResult);
        btnEditResult.setOnClickListener(v -> {
            Intent intent = new Intent(this, Activity5.class);
            startActivity(intent);
        });
    }
}