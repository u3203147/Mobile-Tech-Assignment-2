package com.example.groupassignment2;

import android.net.Uri;

public class ItemResult {
    private String reader;
    private Uri imageUri;

    public ItemResult(String reader, Uri imageUri) {
        this.reader = reader;
        this.imageUri = imageUri;
    }

    public String getReader() {
        return reader;
    }

    public void setReader(String reader) {
        this.reader = reader;
    }

    public Uri getImageUri() {
        return imageUri;
    }

    public void setImageUri(Uri imageUri) {
        this.imageUri = imageUri;
    }
}
