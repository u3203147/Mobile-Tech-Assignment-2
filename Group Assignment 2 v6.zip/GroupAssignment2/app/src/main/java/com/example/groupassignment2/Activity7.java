package com.example.groupassignment2;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Activity7 extends AppCompatActivity {

    private ImageView imageView;
    private TextView textViewReader;
    private TextView textViewResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_7);

        textViewReader = findViewById(R.id.textViewReader);
        textViewResult = findViewById(R.id.textViewResult);
        ImageView imageView = findViewById(R.id.imageViewSelected);
        String filename;

        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            String reader = extras.getString("reader");
            textViewReader.setText(reader);
            String result = extras.getString("result");
            textViewResult.setText(result);

            filename = extras.getString("filename");
            int resId = getResources().getIdentifier(filename, "drawable", getPackageName());
            imageView.setImageResource(resId);
        } else {
            filename = null;
        }

        DatabaseReference dbref = FirebaseDatabase.getInstance().getReference("Storage");

        Button btnEdit = findViewById(R.id.btnEdit);
        Button btnDelete = findViewById(R.id.btnDelete);
        Button btnCancel = findViewById(R.id.btnCancel);

        btnEdit.setOnClickListener(v -> {
            Intent intent = new Intent(this, Activity5.class);
            startActivity(intent);
        });

        btnDelete.setOnClickListener(v -> {
            // Firebase delete logic
            if (filename != null) {
                dbref.child(filename).removeValue();
            }

            Intent intent = new Intent(this, Activity6.class);
            startActivity(intent);
        });

        btnCancel.setOnClickListener(v -> {
            Intent intent = new Intent(this, Activity6.class);
            startActivity(intent);
        });



    }
}