package com.example.groupassignment2;

import android.net.Uri;

public class ItemResult {
    private String reader;
    private String result;
    private String filename;

    public ItemResult() {
        // Empty constructor required for Firebase
    }

    public ItemResult(String reader, String result, String filename) {
        this.reader = reader;
        this.result = result;
        this.filename = filename;
    }

    public String getReader() {
        return reader;
    }

    public void setReader(String reader) {
        this.reader = reader;
    }

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }

    public String getFilename() {
        return filename;
    }

    public void setFilename(String filename) {
        this.filename = filename;
    }

}
