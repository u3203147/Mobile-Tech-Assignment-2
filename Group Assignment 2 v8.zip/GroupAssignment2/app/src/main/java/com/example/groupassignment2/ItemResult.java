package com.example.groupassignment2;

import android.net.Uri;

public class ItemResult {
    private String reader;
    private String text;
    private String filename;

    public ItemResult() {
        // Empty constructor required for Firebase
    }

    public ItemResult(String reader, String text, String filename) {
        this.reader = reader;
        this.text = text;
        this.filename = filename;
    }

    public String getReader() {
        return reader;
    }

    public void setReader(String reader) {
        this.reader = reader;
    }

    public String getText() { return text; }

    public void setText(String text) {
        this.text = text;
    }

    public String getFilename() {
        return filename;
    }

    public void setFilename(String filename) {
        this.filename = filename;
    }

}
