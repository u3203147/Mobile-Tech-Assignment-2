package com.example.groupassignment2;

import static com.example.groupassignment2.ImageUtils.loadImageFromGallery;

import android.content.ContentUris;
import android.content.Context;
import android.database.Cursor;
import android.graphics.Color;
import android.net.Uri;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class Activity6ListViewAdapter extends ArrayAdapter<ItemResult> {
    List<ItemResult> items = new ArrayList<>();
    public Activity6ListViewAdapter(@NonNull Context context, int resource, @NonNull List<ItemResult> objects) {
        super(context, resource, objects);
        items = objects;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.activity_6_list_item, parent, false);
        }

        // Alternate background colours
        if (position % 2 == 0) {
            convertView.setBackgroundColor(Color.parseColor("white"));
        } else {
            convertView.setBackgroundColor(Color.parseColor("lightgrey"));
        }

        ItemResult item = items.get(position);
        ImageView icon = convertView.findViewById(R.id.imageViewListItem);

        String imageName = item.getFilename();
        try {
            Uri imageUri = loadImageFromGallery(getContext(), imageName + ".png");
            if (imageUri != null) {
                icon.setImageURI(imageUri);
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        TextView textViewItem = convertView.findViewById(R.id.textViewItem);
        textViewItem.setText(item.getReader());

        return convertView;
    }

}