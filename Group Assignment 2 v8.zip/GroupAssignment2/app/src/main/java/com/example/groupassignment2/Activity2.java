package com.example.groupassignment2;

import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.Html;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.mlkit.vision.barcode.BarcodeScanner;
import com.google.mlkit.vision.barcode.BarcodeScannerOptions;
import com.google.mlkit.vision.barcode.BarcodeScanning;
import com.google.mlkit.vision.barcode.common.Barcode;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.label.ImageLabel;
import com.google.mlkit.vision.label.ImageLabeler;
import com.google.mlkit.vision.label.ImageLabeling;
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import android.text.SpannableString;
import android.text.style.StyleSpan;
import android.graphics.Typeface;

import java.util.List;

public class Activity2 extends AppCompatActivity {

    private static final int REQUEST_PERMISSION = 3000;
    private Uri imageFileUri;

    private String reader;

    // UI fields (needed in callbacks)
    private Button btnEditResult;
    private TextView textViewInstruction;
    private TextView textViewReaderTitle;
    private ImageView imageViewSelected;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_2);

        imageViewSelected = findViewById(R.id.imageViewSelected);
        textViewReaderTitle = findViewById(R.id.textViewReaderTitle);
        textViewInstruction = findViewById(R.id.textViewInstruction);
        btnEditResult = findViewById(R.id.btnEditResult);

        btnEditResult.setVisibility(View.INVISIBLE);

        Bundle extras = getIntent().getExtras();
        reader = (extras != null) ? extras.getString("reader") : "barcode";
        if ("barcode".equals(reader)) {
            imageViewSelected.setImageResource(R.drawable.barcode);

        } else if ("content".equals(reader)) {
            imageViewSelected.setImageResource(R.drawable.content);

        } else {
            imageViewSelected.setImageResource(R.drawable.text);
        }

        btnEditResult.setOnClickListener(v -> {

            String resultText = textViewInstruction.getText().toString();

            Intent intent = new Intent(Activity2.this, Activity5.class);

            intent.putExtra("reader", reader);
            intent.putExtra("result", resultText);
            intent.putExtra("imageUri", imageFileUri.toString());

            startActivity(intent);
        });
    }

    private boolean checkPermission() {
        String permission = android.Manifest.permission.CAMERA;
        boolean granted = ContextCompat.checkSelfPermission(this, permission)
                == PackageManager.PERMISSION_GRANTED;
        if (!granted) {
            ActivityCompat.requestPermissions(this,
                    new String[]{permission}, REQUEST_PERMISSION);
        }
        return granted;
    }

    public void openCamera(View view) {
        if (!checkPermission()) return;

        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        imageFileUri = getContentResolver().insert(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                new ContentValues()
        );
        intent.putExtra(MediaStore.EXTRA_OUTPUT, imageFileUri);
        activityResultLauncher.launch(intent);
    }

    public void loadImage(View view) {
        Intent intent = new Intent(Intent.ACTION_PICK,
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        activityResultLauncher.launch(intent);
    }

    ActivityResultLauncher<Intent> activityResultLauncher =
            registerForActivityResult(
                    new ActivityResultContracts.StartActivityForResult(),
                    new ActivityResultCallback<ActivityResult>() {
                        @Override
                        public void onActivityResult(ActivityResult result) {
                            if (result.getResultCode() == RESULT_OK) {

                                if (result.getData() != null && result.getData().getData() != null) {
                                    imageFileUri = result.getData().getData();
                                }

                                imageViewSelected.setImageURI(imageFileUri);
                                if ("barcode".equals(reader)) {
                                    textViewReaderTitle.setText("Barcode Reader");
                                } else if ("content".equals(reader)) {
                                    textViewReaderTitle.setText("Content Reader");
                                } else {
                                    textViewReaderTitle.setText("Text Reader");
                                }

                                if (imageFileUri != null) {
                                    try {
                                        InputImage image = InputImage.fromFilePath(Activity2.this, imageFileUri);

                                        if ("barcode".equals(reader)) {
                                            processImageFromBarcodeReader(image);
                                        } else if ("content".equals(reader)) {
                                            processImageFromContentReader(image);
                                        } else {
                                            processImageFromTextReader(image);
                                        }

                                    } catch (Exception e) {
                                        e.printStackTrace();
                                    }
                                }
                            }
                        }
                    });

    public void processImageFromBarcodeReader(InputImage image) {
        BarcodeScannerOptions options = new BarcodeScannerOptions.Builder()
                .setBarcodeFormats(Barcode.FORMAT_ALL_FORMATS)
                .build();

        BarcodeScanner scanner = BarcodeScanning.getClient(options);

        scanner.process(image)
                .addOnSuccessListener(new OnSuccessListener<List<Barcode>>() {
                    @Override
                    public void onSuccess(List<Barcode> barcodes) {
                        SpannableString boldText = new SpannableString("Detected barcode:");
                        boldText.setSpan(new StyleSpan(Typeface.BOLD), 0, boldText.length(), 0);
                        textViewInstruction.setText(boldText);

                        String result = "";
                        for (Barcode barcode : barcodes) {
                            result = barcode.getRawValue();
                            textViewInstruction.append("\n" + result);
                        }

                        if (result.length() < 2) {
                            textViewInstruction.append("\nBarcode not found");
                        }

                        btnEditResult.setVisibility(View.VISIBLE);
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        textViewInstruction.setText("Failed");
                    }
                });
    }

    public void processImageFromContentReader(InputImage image) {
        ImageLabeler labeler = ImageLabeling.getClient(
                ImageLabelerOptions.DEFAULT_OPTIONS);

        labeler.process(image)
                .addOnSuccessListener(new OnSuccessListener<List<ImageLabel>>() {
                    @Override
                    public void onSuccess(List<ImageLabel> labels) {

                        SpannableString boldText = new SpannableString("Recognised Image Content:\n");
                        boldText.setSpan(new StyleSpan(Typeface.BOLD), 0, boldText.length(), 0);
                        textViewInstruction.setText(boldText);

                        int i = 1;
                        for (ImageLabel label : labels) {
                            textViewInstruction.append(
                                    i + ". " + label.getText() + " (" +
                                            String.format("%.1f", label.getConfidence() * 100) + "%)\n"
                            );
                            i++;
                        }

                        btnEditResult.setVisibility(View.VISIBLE);
                    }
                })
                .addOnFailureListener(e -> textViewInstruction.setText("Failed"));
    }

    public void processImageFromTextReader(InputImage image) {
        TextRecognizer recognizer = TextRecognition.getClient(
                TextRecognizerOptions.DEFAULT_OPTIONS);

        recognizer.process(image)
                .addOnSuccessListener(new OnSuccessListener<Text>() {
                    @Override
                    public void onSuccess(Text visionText) {
                        String heading = "Extracted text:\n";
                        String fullText = heading + visionText.getText();

                        SpannableString spannable = new SpannableString(fullText);
                        spannable.setSpan(new StyleSpan(Typeface.BOLD), 0, heading.length(), 0);

                        textViewInstruction.setText(spannable);
                        btnEditResult.setVisibility(View.VISIBLE);
                    }
                })
                .addOnFailureListener(e -> textViewInstruction.setText("Failed"));
    }
}
