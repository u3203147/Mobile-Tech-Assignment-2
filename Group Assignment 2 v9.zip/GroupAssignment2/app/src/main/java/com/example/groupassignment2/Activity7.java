package com.example.groupassignment2;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.io.IOException;

public class Activity7 extends AppCompatActivity {

    private ImageView imageView;
    private TextView textViewReader;
    private TextView textViewResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_7);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });


        textViewReader = findViewById(R.id.textViewReader);
        textViewResult = findViewById(R.id.textViewResult);
        ImageView imageView = findViewById(R.id.imageViewSelected);
        String reader;
        String result;
        String filename;

        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            reader = extras.getString("reader");
            textViewReader.setText(reader);
            result = extras.getString("result");
            textViewResult.setText(result);

            filename = extras.getString("filename");

            Uri imageUri = null;
            try {
                imageUri = ImageUtils.loadImageFromGallery(this, filename + ".png");
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            imageView.setImageURI(imageUri);
        } else {
            reader = "";
            result = "";
            filename = null;
        }

        DatabaseReference dbref = FirebaseDatabase.getInstance().getReference("Storage");

        Button btnEdit = findViewById(R.id.btnEdit);
        Button btnDelete = findViewById(R.id.btnDelete);
        Button btnCancel = findViewById(R.id.btnCancel);

        btnEdit.setOnClickListener(v -> {
            Intent intent = new Intent(this, Activity5.class);
            intent.setAction("FROM_GALLERY");
            intent.putExtra("reader", reader);
            intent.putExtra("result", result);
            intent.putExtra("imageUri", filename);
            startActivity(intent);
        });

        btnDelete.setOnClickListener(v -> {
            // Firebase delete logic
            if (filename != null) {
                dbref.child(filename).removeValue();
            }

            Intent intent = new Intent(this, Activity6.class);
            startActivity(intent);
        });

        btnCancel.setOnClickListener(v -> {
            Intent intent = new Intent(this, Activity6.class);
            startActivity(intent);
        });



    }
}