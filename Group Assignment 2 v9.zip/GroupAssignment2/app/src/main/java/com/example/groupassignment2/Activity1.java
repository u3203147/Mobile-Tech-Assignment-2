package com.example.groupassignment2;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;


public class Activity1 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_1);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        ImageView imageViewBarcode = findViewById(R.id.imageViewBarcodeReader);
        ImageView imageViewContent = findViewById(R.id.imageViewContentReader);
        ImageView imageViewText    = findViewById(R.id.imageViewTextReader);
        Button    btnList          = findViewById(R.id.btnListOfAnalysedImages);

        imageViewBarcode.setOnClickListener(v -> openActivity2("Barcode Reader"));
        imageViewContent.setOnClickListener(v -> openActivity2("Content Reader"));
        imageViewText.setOnClickListener(v -> openActivity2("Text Reader"));

        btnList.setOnClickListener(v -> {
            Intent intent = new Intent(this, Activity6.class);
            startActivity(intent);
        });
    }

    private void openActivity2(String reader) {
        Intent intent = new Intent(this, Activity2.class);
        intent.putExtra("reader", reader);
        startActivity(intent);
    }
}