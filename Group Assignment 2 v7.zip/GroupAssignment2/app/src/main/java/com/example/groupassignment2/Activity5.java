package com.example.groupassignment2;

import android.content.ContentValues;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.ImageDecoder;
import android.net.Uri;
import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.io.IOException;
import java.io.OutputStream;

public class Activity5 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_5);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Bundle extras = getIntent().getExtras();
        String reader = extras.getString("reader");
        String result = extras.getString("result");
        String imageUriString = extras.getString("imageUri");


        EditText heading = findViewById(R.id.editTextReader);
        EditText editTextResult = findViewById(R.id.editTextResult);
        ImageView imageView = findViewById(R.id.imageViewSelected);

        if ("barcode".equals(reader)) {
            heading.setText("Barcode Reader");
        } else if ("content".equals(reader)) {
            heading.setText("Content Reader");
        } else {
            heading.setText("Text Reader");
        }

        // SET RESULT (editable + underline)
        editTextResult.setText(result);

        // SET IMAGE (fixed)
        Uri imageUri = Uri.parse(imageUriString);
        imageView.setImageURI(imageUri);

        DatabaseReference dbref = FirebaseDatabase.getInstance().getReference("Storage");

        Button save_button = findViewById(R.id.btnSave);
        save_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Save text to Firebase database
                String uniqueFileName = dbref.push().getKey();
                dbref.child(uniqueFileName).child("filename").setValue(uniqueFileName);
                dbref.child(uniqueFileName).child("reader").setValue(reader);
                dbref.child(uniqueFileName).child("text").setValue(result);

                // Save image to gallery
                Bitmap bitmap = getBitmapFromUri(imageUri);
                saveImageToGallery(bitmap, uniqueFileName, Activity5.this);

                // Go to Activity 6
                Intent intent = new Intent(Activity5.this, Activity6.class);
                startActivity(intent);
            }
        });

    }

    private Bitmap getBitmapFromUri(Uri uri) {
        try {
            ImageDecoder.Source source = ImageDecoder.createSource(getContentResolver(), uri);
            Bitmap bitmap = ImageDecoder.decodeBitmap(source);
            return bitmap;
        } catch (IOException e) {
            Log.e("URI_TO_BITMAP", "Failed to load image", e);
            return null;
        }
    }

    private void saveImageToGallery(Bitmap bitmap, String fileName, Context context) {
        ContentValues values = new ContentValues();
        values.put(MediaStore.Images.Media.DISPLAY_NAME, fileName);
        values.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
        values.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES);
        Uri imageUri = context.getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
        try {
            OutputStream outputStream = context.getContentResolver().openOutputStream(imageUri);
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, outputStream);
            outputStream.flush();
            outputStream.close();
            Log.d("SAVE_GALLERY", "Image saved to gallery: " + imageUri.toString());
        } catch (IOException e) {
            Log.e("SAVE_GALLERY", "Error saving image", e);
        }
    }
}