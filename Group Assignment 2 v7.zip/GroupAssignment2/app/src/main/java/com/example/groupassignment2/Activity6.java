package com.example.groupassignment2;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class Activity6 extends AppCompatActivity {

    String reader = "No reader available";
    String result = "No result available";
    String filename;
    Uri uri = Uri.EMPTY;
    List<ItemResult> dbResults = new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_6);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Activity6ListViewAdapter listViewAdapter = new Activity6ListViewAdapter(Activity6.this, R.layout.activity_6_list_item, dbResults);
        ListView listView = findViewById(R.id.listView);
        listView.setAdapter(listViewAdapter);

        DatabaseReference dbref = FirebaseDatabase.getInstance().getReference("Storage");
        dbref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                dbResults.clear();

                for (DataSnapshot childSnapshot : snapshot.getChildren()) {
                    ItemResult item = childSnapshot.getValue(ItemResult.class);
                    if (item != null) {
                        dbResults.add(item);
                    }
                }

                listViewAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });


        Button add_button = findViewById(R.id.btnAdd);
        add_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Activity6.this, Activity1.class);
                startActivity(intent);
            }
        });



        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                        ItemResult item = dbResults.get(position);
                        Intent intent = new Intent(view.getContext(), Activity7.class);
                        intent.putExtra("reader", item.getReader());
                        intent.putExtra("result", item.getResult());
                        intent.putExtra("filename", item.getFilename());
                        startActivity(intent);
                    }
                });
    }
}