package com.example.groupassignment2;

import android.content.Context;
import android.graphics.Color;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class Activity6ListViewAdapter extends ArrayAdapter<ItemResult> {
    List<ItemResult> items = new ArrayList<>();
    public Activity6ListViewAdapter(@NonNull Context context, int resource, @NonNull List<ItemResult> objects) {
        super(context, resource, objects);
        items = objects;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.activity_6_list_item, parent, false);
        }

        if (position % 2 == 0) {
            convertView.setBackgroundColor(Color.parseColor("white"));
        } else {
            convertView.setBackgroundColor(Color.parseColor("lightgrey"));
        }

        ItemResult item = items.get(position);
        ImageView icon = convertView.findViewById(R.id.imageViewListItem);
        icon.setImageURI(item.getImageUri());
        TextView textViewItem = convertView.findViewById(R.id.textViewItem);
        textViewItem.setText(item.getReader());

        return convertView;
    }
}