package com.example.groupassignment2;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;
import java.util.List;

public class Activity6 extends AppCompatActivity {

    String reader = "No reader available";
    String result = "No result available";
    String filename;
    Uri uri = Uri.EMPTY;
    List<ItemResult> itemResults = new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_6);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Button add_button = findViewById(R.id.btnAdd);
        add_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Activity6.this, Activity1.class);
                startActivity(intent);
            }
        });

        Uri imageUri1 = Uri.parse("android.resource://" + getPackageName() + "/" + R.drawable.barcode);
        Uri imageUri2 = Uri.parse("android.resource://" + getPackageName() + "/" + R.drawable.content);
        Uri imageUri3 = Uri.parse("android.resource://" + getPackageName() + "/" + R.drawable.text);
        itemResults.add(new ItemResult("Test", "barcode", imageUri1));
        itemResults.add(new ItemResult("Test2", "content", imageUri2));
        itemResults.add(new ItemResult("Test3", "text", imageUri3));
        itemResults.add(new ItemResult("Test4", "barcode", imageUri1));
        itemResults.add(new ItemResult("Test5", "content", imageUri2));
        itemResults.add(new ItemResult("Test6", "text", imageUri3));
        itemResults.add(new ItemResult("Test7", "barcode", imageUri1));

        Activity6ListViewAdapter listViewAdapter = new Activity6ListViewAdapter(Activity6.this, R.layout.activity_6_list_item, itemResults);
        ListView listView = findViewById(R.id.listView);
        listView.setAdapter(listViewAdapter);

        listView.setOnItemClickListener(
                new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int
                            position, long id) {
                        ItemResult res = itemResults.get(position);
                        Intent intent = new Intent(view.getContext(), Activity7.class);
                        intent.putExtra("reader", res.getReader());
                        intent.putExtra("result", res.getResult());
                        intent.putExtra("uri", res.getImageUri().toString());
                        startActivity(intent);
                    }
                });
    }
}